package agent;

import org.objectweb.asm.*;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.reflect.Method;
import java.security.ProtectionDomain;
import java.util.Arrays;

public class DependencyScanner implements ClassFileTransformer {

    private static final Method adjustStacktraceMethod;

    static {
        try {
            adjustStacktraceMethod = DependencyScanner.class.getDeclaredMethod("adjustStackTrace", Throwable.class);
        } catch (NoSuchMethodException e) {
            throw new AssertionError(e);
        }
    }

    public static void adjustStackTrace(Throwable throwable) {
        throwable.fillInStackTrace();
        StackTraceElement[] stackTrace = throwable.getStackTrace();
        throwable.setStackTrace(Arrays.copyOfRange(stackTrace,1,stackTrace.length));
    }

    @Override
    public byte[] transform(ClassLoader loader, final String name,
                            Class<?> clazz, ProtectionDomain domain, byte[] bytecode)
            throws IllegalClassFormatException {
        ClassReader classReader = new ClassReader(bytecode);
        ClassWriter classWriter = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        classReader.accept(new ClassVisitor(Opcodes.ASM5, classWriter) {

            @Override
            public MethodVisitor visitMethod(int access, String name,
                                             String desc, String signature, String[] exceptions) {
                return new MethodVisitor(Opcodes.ASM5, super.visitMethod(
                        access, name, desc, signature, exceptions)) {
                    @Override
                    public void visitInsn(int opcode) {
                        if (opcode == Opcodes.ATHROW) {
                            try {
                                super.visitInsn(Opcodes.DUP);
                                super.visitMethodInsn(Opcodes.INVOKESTATIC, Type.getInternalName(DependencyScanner.class),adjustStacktraceMethod.getName(), Type.getMethodDescriptor(adjustStacktraceMethod), false);
                            } catch (SecurityException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                        super.visitInsn(opcode);
                    }
                };
            }

        }, 0);
        return classWriter.toByteArray();
        // ClassReader
        // visit API

    }

}
