package agent;

import org.objectweb.asm.*;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.reflect.Method;
import java.security.ProtectionDomain;
import java.util.Arrays;

public class DependencyScanner implements ClassFileTransformer {

    private static final Method adjustStackTraceMethod;

    static {
        try {
            adjustStackTraceMethod = DependencyScanner.class.getDeclaredMethod("adjustStackTrace", Throwable.class, int.class);
        } catch (NoSuchMethodException e) {
            throw new AssertionError(e);
        }
    }

    public static void adjustStackTrace(Throwable throwable, int lineNumber) {
        throwable.fillInStackTrace();
        StackTraceElement[] stackTrace = throwable.getStackTrace();
        StackTraceElement e = stackTrace[1];
        stackTrace[1] = new StackTraceElement(e.getClassName(), e.getMethodName(), e.getFileName(), lineNumber);
        throwable.setStackTrace(Arrays.copyOfRange(stackTrace, 1, stackTrace.length));
    }

    @Override
    public byte[] transform(ClassLoader loader, final String name,
                            Class<?> clazz, ProtectionDomain domain, byte[] bytecode)
            throws IllegalClassFormatException {
        ClassReader classReader = new ClassReader(bytecode);
        ClassWriter classWriter = new ClassWriter(ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES);
        classReader.accept(new ClassVisitor(Opcodes.ASM5, classWriter) {

            @Override
            public MethodVisitor visitMethod(int access, String name,
                                             String desc, String signature, String[] exceptions) {
                return new MethodVisitor(Opcodes.ASM5, super.visitMethod(
                        access, name, desc, signature, exceptions)) {
                    int currentLineNumber;

                    @Override
                    public void visitLineNumber(int i, Label label) {
                        currentLineNumber = i;
                        super.visitLineNumber(i, label);
                    }

                    @Override
                    public void visitInsn(int opcode) {
                        if (opcode == Opcodes.ATHROW) {
                            try {
                                super.visitInsn(Opcodes.DUP);
                                super.visitLdcInsn(currentLineNumber);
                                super.visitMethodInsn(Opcodes.INVOKESTATIC, Type.getInternalName(DependencyScanner.class), adjustStackTraceMethod.getName(), Type.getMethodDescriptor(adjustStackTraceMethod), false);
                            } catch (SecurityException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                        super.visitInsn(opcode);
                    }
                };
            }

        }, 0);
        return classWriter.toByteArray();
        // ClassReader
        // visit API

    }

}
